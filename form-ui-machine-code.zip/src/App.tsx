import "./styles.css";
import TabForm from "./components/TabForm/index";

export default function App() {
  return (
    <div className="App">
      <TabForm />
    </div>
  );
}
