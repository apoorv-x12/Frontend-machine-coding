export type Props = {
  formData: {
    name: string;
    age: number;
    email: string;
    preferences: Array<string>;
    theme: string;
  };
  setFormData: Function;
  errors: Err;
};

export type Err = {
  name: string;
  age: string;
  email: string;
  preferences: string;
  theme: string;
};
