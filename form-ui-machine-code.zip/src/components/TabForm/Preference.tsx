import { Props } from "./types";

function Preference(props: Props) {
  const { formData, setFormData, errors } = props;

  const handlePreferences = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev: typeof formData) => ({
      ...prev,
      preferences: e.target.checked
        ? [...prev.preferences, e.target.name]
        : prev.preferences.filter((item) => item !== e.target.name),
    }));
  };

  return (
    <>
      <div>
        Preferences <span className="star">*</span> :
      </div>
      {errors?.preferences && <div className="star">{errors?.preferences}</div>}
      <br />
      <div className="fields-preference">
        <div className="field-preference">
          <label>India:</label>
          <input
            type="checkbox"
            name={"india"}
            checked={formData.preferences.indexOf("india") != -1}
            onChange={(e) => handlePreferences(e)}
          />
        </div>
        <div className="field-preference">
          <label>China:</label>
          <input
            type="checkbox"
            name={"china"}
            checked={formData.preferences.indexOf("china") != -1}
            onChange={(e) => handlePreferences(e)}
          />
        </div>
        <div className="field-preference">
          <label>Usa:</label>
          <input
            type="checkbox"
            name={"usa"}
            checked={formData.preferences.indexOf("usa") != -1}
            onChange={(e) => handlePreferences(e)}
          />
        </div>
      </div>
    </>
  );
}

export default Preference;
