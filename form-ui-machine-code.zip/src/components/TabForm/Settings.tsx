import { Props } from "./types";

function Settings(props: Props) {
  const { formData, setFormData } = props;
  const handleSettings = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev: typeof formData) => ({
      ...prev,
      theme: e.target.name,
    }));
  };

  return (
    <>
      <div>Theme:</div>
      <br />
      <div className="fields-settings">
        <div className="field-settings">
          <label>dark:</label>
          <input
            type="radio"
            name={"dark"}
            checked={formData.theme === "dark"}
            onChange={(e) => handleSettings(e)}
          />
        </div>
        <div className="field-settings">
          <label>light:</label>
          <input
            type="radio"
            name={"light"}
            checked={formData.theme === "light"}
            onChange={(e) => handleSettings(e)}
          />
        </div>
      </div>
    </>
  );
}

export default Settings;
