import Profile from "./Profile";
import Preference from "./Preference";
import Settings from "./Settings";
import { useState } from "react";
import { Err } from "./types";

function Config() {
  const [errors, setErrors] = useState({
    name: "",
    age: "",
    email: "",
    preferences: "",
    theme: "",
  });
  const [formData, setFormData] = useState({
    name: "",
    age: 18,
    email: "",
    preferences: [],
    theme: "dark",
  });
  const tabs = [
    {
      name: "Profile",
      component: Profile,
      validate: () => {
        const err: Err = {
          name: "",
          age: "",
          email: "",
          preferences: "",
          theme: "",
        };
        if (!formData.name || formData.name.length < 2) {
          err.name = "invalid name";
        }
        if (!formData.age || formData.age < 18) {
          err.age = "invalid age";
        }
        if (formData.email && formData.email.length < 18) {
          err.email = "invalid email";
        }

        setErrors((prev) => err);

        return err.age || err.name || (formData.email ? err.email : false)
          ? false
          : true;
      },
      validateWithoutCustomErrorSet: () => {
        if (!formData.name || formData.name.length < 2) {
          return false;
        }
        if (!formData.age || formData.age < 18) {
          return false;
        }
        if (formData.email && formData.email.length < 18) {
          return false;
        }

        setErrors((prev) => ({
          name: "",
          age: "",
          email: "",
          preferences: "",
          theme: "",
        }));
        return true;
      },
    },
    {
      name: "Preference",
      component: Preference,
      validate: () => {
        const err: Err = {
          name: "",
          age: "",
          email: "",
          preferences: "",
          theme: "",
        };
        if (formData.preferences.length < 1) {
          err.preferences = "invalid preferences";
        }

        setErrors((prev) => err);

        return !err.preferences ? true : false;
      },
      validateWithoutCustomErrorSet: () => {
        let bool = true;
        if (formData.preferences.length < 1) {
          bool = false;
        }
        setErrors((prev) => ({
          name: "",
          age: "",
          email: "",
          preferences: "",
          theme: "",
        }));

        return bool;
      },
    },
    {
      name: "Settings",
      component: Settings,
      validate: () => {
        return true;
      },
      validateWithoutCustomErrorSet: () => {
        return true;
      },
    },
  ];

  return {
    tabs,
    errors,
    setErrors,
    formData,
    setFormData,
  };
}
export default Config;
