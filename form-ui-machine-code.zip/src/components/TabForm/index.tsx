import { useState } from "react";
import Config from "./config";
import "./styles.css";

function TabForm() {
  const { tabs, errors, setErrors, formData, setFormData } = Config();
  const [activeTab, setActiveTab] = useState(0);

  const ActiveChild = tabs[activeTab].component;

  const handleTabChange = (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>,
    index: number
  ) => {
    if (
      tabs[activeTab].validateWithoutCustomErrorSet() &&
      tabs[index].validateWithoutCustomErrorSet()
    )
      setActiveTab((prev) => index);
  };

  const handleSubmitClick = (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    console.log(formData);
  };

  const handleNextClick = (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    if (tabs[activeTab].validate()) setActiveTab((prev) => prev + 1);
  };
  const handlePrevClick = (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    setActiveTab((prev) => prev - 1);
  };

  return (
    <>
      <div className="tabs">
        {tabs?.map((tab, index) => {
          return (
            <button
              key={index}
              className="tab-item"
              onClick={(e) => handleTabChange(e, index)}
            >
              {tab.name}
            </button>
          );
        })}
      </div>

      <div className="child-tab">
        <ActiveChild
          formData={formData}
          setFormData={setFormData}
          errors={errors}
        />
      </div>

      <div className="navigate">
        {activeTab !== tabs.length - 1 ? (
          <button className="navigation" onClick={(e) => handleNextClick(e)}>
            next
          </button>
        ) : (
          <div> </div>
        )}
        {activeTab !== 0 ? (
          <button className="navigation" onClick={(e) => handlePrevClick(e)}>
            prev
          </button>
        ) : (
          <div> </div>
        )}

        <div>
          {activeTab === tabs.length - 1 ? (
            <button
              className="navigation"
              onClick={(e) => handleSubmitClick(e)}
            >
              Submit
            </button>
          ) : (
            <div></div>
          )}
        </div>
      </div>
    </>
  );
}

export default TabForm;
