import { Props } from "./types";

function Profile(props: Props) {
  const { formData, setFormData, errors } = props;

  const handleName = (e: React.ChangeEvent<HTMLInputElement>, key: string) => {
    setFormData((prev: typeof formData) => ({
      ...prev,
      [key]: e.target.value,
    }));
  };

  return (
    <>
      <div className="fields-profile">
        <div className="field">
          <label>
            Name <span className="star">*</span> :
          </label>
          <div>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleName(e, "name")}
            />
            {errors?.name && <div className="star">{errors?.name}</div>}
          </div>
        </div>
        <div className="field">
          <label>
            Age <span className="star">*</span> :
          </label>
          <div className="field-age-input">
            <input
              type="number"
              value={formData.age}
              onChange={(e) => handleName(e, "age")}
            />
            {errors?.age && <div className="star">{errors?.age}</div>}
          </div>
        </div>
        <div className="field">
          <label>Email :</label>
          <div className="field-email-input">
            <input
              type="text"
              value={formData.email}
              onChange={(e) => handleName(e, "email")}
            />
            {errors?.email && <div className="star">{errors?.email}</div>}
          </div>
        </div>
      </div>
    </>
  );
}

export default Profile;
