import "./styles.css";
import Pagination from "./components/Pagination/index";

export default function App() {
  return (
    <div className="App">
      <Pagination />
    </div>
  );
}
