
type Prop={
     image:string;
     title:string
}
function Item(props: Prop) {
const {image,title}=props;

  return (
    <>
      <div>
        <img src={image} alt="error loading image" />
      </div>
      <div>{title}</div>
    </>
  );
}
export default Item;
