import { useEffect, useMemo, useState, useCallback } from "react";
import { ArrProduct } from "./types";

function useData(url: string) {
  const [dataPreserved, setDataPreserved] = useState([]);
  const [data, setData] = useState([]);
  const [load, setLoad] = useState(false);
  const [error, setError] = useState("");
  const [items, setItems] = useState(5);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");

  const transformData = useCallback(
    (
      data: ArrProduct,
      items: number
    ): { dataSlices: ArrProduct[]; numbers: number[][] } => {
      const dataOfSlices: ArrProduct[] = [];
      const numberWindow: number[][] = [];

      for (let i = 0; i < data.length; i += items) {
        dataOfSlices?.push(data.slice(i, i + items));
      }

      const windowSize = dataOfSlices?.length < 10 ? dataOfSlices?.length : 10;
      const arr: number[] = [];
      for (let i = 0; i < dataOfSlices?.length; i += 1) {
        arr.push(i);
      }
      for (let i = 0; i < arr?.length; i += windowSize) {
        numberWindow.push(arr?.slice(i, i + windowSize));
      }
      return {
        dataSlices: dataOfSlices,
        numbers: numberWindow,
      };
    },
    [data, items]
  );

  const { dataSlices, numbers } = transformData(data, items);

  const pages = useMemo(() => dataSlices?.length, [dataSlices]);
  const [currentWindow, setCurrentWindow] = useState(0);

  const fetchData = async () => {
    try {
      setLoad(true);
      const data = await fetch(url);
      const json = await data.json();

      setData((prev) => json.products);
      setDataPreserved((prev) => json.products);
    } catch (e) {
      setError("Couldn't fetch data");
    } finally {
      setLoad(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [url]);

  return {
    error,
    load,
    dataSlices: dataSlices[page],
    page,
    setPage,
    setItems,
    search,
    setSearch,
    items,
    pages,
    setData,
    numbers: numbers[currentWindow],
    setCurrentWindow,
    dataPreserved,
  };
}

export default useData;
