export type Recipe = {
  id: number;
  name: string;
  image: string;
  cuisine: string;
  difficulty: "Easy" | "Medium" | "Hard"; // you can widen this if more values are allowed
  caloriesPerServing: number;
  prepTimeMinutes: number;
  cookTimeMinutes: number;
  servings: number;
  rating: number;
  reviewCount: number;
  ingredients: string[];
  instructions: string[];
  mealType: ("Breakfast" | "Lunch" | "Dinner" | "Snack")[]; // inferred from values; extendable
  tags: string[];
  userId: number;
};

type ProductListResponse = {
  products: Product[];
  total: number;
  skip: number;
  limit: number;
};

export type Product = {
  id: number;
  title: string;
  description: string;
  category: string;
  price: number;
  discountPercentage: number;
  rating: number;
  stock: number;
  tags: string[];
  brand: string;
  sku: string;
  weight: number;
  dimensions: Dimensions;
  warrantyInformation: string;
  shippingInformation: string;
  availabilityStatus: "In Stock" | "Low Stock" | "Out of Stock"; // Extend as needed
  reviews: Review[];
  returnPolicy: string;
  minimumOrderQuantity: number;
  meta: Meta;
  thumbnail: string;
  images: string[];
};

export type ArrProduct=Product[]

type Dimensions = {
  width: number;
  height: number;
  depth: number;
};

type Review = {
  rating: number;
  comment: string;
  date: string; // or Date, if parsed
  reviewerName: string;
  reviewerEmail: string;
};

type Meta = {
  createdAt: string; // or Date
  updatedAt: string; // or Date
  barcode: string;
  qrCode: string;
};
