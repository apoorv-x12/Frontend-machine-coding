import { useState } from "react";
import useData from "./getData";
import "./styles.css";
import { Product } from "./types";
import Item from "./Item";

function Pagination() {
  const [url, setUrl] = useState("https://dummyjson.com/products?limit=167");
  const {
    error,
    load,
    dataSlices,
    items,
    page,
    setItems,
    pages,
    numbers,
    setPage,
    setCurrentWindow,
    search,
    setSearch,
    setData,
    dataPreserved,
  } = useData(url);
  const handlePrev = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    if (page % 10 == 0) {
      setCurrentWindow((prev) => prev - 1);
    }
    setPage((prev) => prev - 1);
  };
  const handleNext = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    if (page % 10 == 9) {
      setCurrentWindow((prev) => prev + 1);
    }
    setPage((prev) => prev + 1);
  };
  const handleNumCLick = (
    e: React.MouseEvent<HTMLDivElement, MouseEvent>,
    item: number
  ) => {
    setPage(item);
  };
  const handlePage = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setItems(Number(e.target.value));
    setPage(0);
    setCurrentWindow(0);
  };
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setData((prev) =>
      dataPreserved?.filter((item: Product, index: number) => {
        return item?.title
          ?.toLowerCase()
          ?.includes(e.target.value.toLowerCase());
      })
    );
    setPage(0);
    setCurrentWindow(0);
  };
  return (
    <>
      <div>Items:</div> <br />
      <div>
        Search:{" "}
        <input type="text" onChange={(e) => handleSearch(e)} value={search} />
      </div>{" "}
      <br />
      {load && <div>Items are loading</div>}
      {error && <div>{error}</div>}
      {!error && !load && dataSlices?.length === 0 ? (
        <div>No Items</div>
      ) : (
        <div className="paginate">
          <div className="items">
            {dataSlices?.map((item: Product) => {
              return (
                <div className="item" key={item.id}>
                  <Item title={item.title} image={item.thumbnail} />
                </div>
              );
            })}
          </div>
          <div className="paginate-footer">
            <select
              name="itemsPerPage"
              id="itemsPerPage"
              onChange={(e) => handlePage(e)}
            >
              {[5, 10, 20, 40, 80].map((item: number, index: number) => {
                return (
                  <option key={index} value={item}>
                    {item}
                  </option>
                );
              })}
            </select>
            {page !== 0 && <button onClick={(e) => handlePrev(e)}>prev</button>}
            <div className="numbers">
              {numbers?.map((item) => (
                <div
                  onClick={(e) => handleNumCLick(e, item)}
                  className={
                    item !== page ? "num-item" : "num-item clickedPage"
                  }
                  key={item}
                >
                  {item + 1}
                </div>
              ))}
            </div>
            {page !== pages - 1 && (
              <button onClick={(e) => handleNext(e)}>next</button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
export default Pagination;
